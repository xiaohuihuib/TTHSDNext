declare module 'ffi-napi' {
    export interface Library {
        [key: string]: any;
    }
    // 接受只读或可变的元组
    export function Library(
        libPath: string, 
        functions: Record<string, readonly [string, readonly string[]] | [string, string[]]>
    ): Library;
    export const Callback: any;
    export const Function: any;
}

declare module 'ref-napi' {
    export function alloc(type: string, value?: any): Buffer;
    export function readCString(buffer: Buffer): string;
}
